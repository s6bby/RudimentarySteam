import pygame  # Import pygame library (graphics, input handling, sound, timing)


# Centralized color dictionary to avoid magic numbers throughout the program.
# Each value is an RGB tuple (Red, Green, Blue).
colors = {
    "black": (0, 0, 0),            # RGB for black
    "white": (255, 255, 255),      # RGB for white
    "red": (255, 0, 0),            # RGB for red
    "green": (0, 255, 0),          # RGB for green
    "blue": (0, 0, 255),           # RGB for blue
    "shoppurple": (94, 76, 224),   # Custom purple for shop background
    "mainmenured": (224, 94, 76),  # Custom red for main menu background
    "yellow": (255, 255, 0),
    "orange": (255, 165, 0),
    "purple": (128, 0, 128),
    "pink": (255, 192, 203),
    "cyan": (0, 255, 255),
    "magenta": (255, 0, 255),
    "gray": (128, 128, 128),
    "lightgray": (200, 200, 200)
}


class Explosion:
    """
    Represents a temporary visual explosion effect.
    Responsible for:
    - Growing in size over time
    - Fading out via alpha transparency
    - Reporting when it is finished
    """

    def __init__(self, pos):
        self.pos = pygame.Vector2(pos)  # Store position using a Vector2 (allows float precision)
        self.radius = 5                 # Initial radius of explosion circle
        self.max_radius = 60            # Maximum radius before explosion is considered done
        self.growth_speed = 300         # Speed at which radius increases (pixels per second)
        self.alpha = 255                # Opacity (255 fully visible, 0 fully transparent)

    def update(self, dt):
        # Increase radius based on growth speed and delta time
        # dt makes animation frame-rate independent
        self.radius += self.growth_speed * dt

        # Reduce opacity over time (fade effect)
        self.alpha -= 400 * dt

        # Clamp alpha so it never becomes negative
        if self.alpha < 0:
            self.alpha = 0

    def draw(self, screen):
        # If fully transparent, skip rendering
        if self.alpha <= 0:
            return

        # Create a temporary surface that supports per-pixel transparency
        surface = pygame.Surface((150, 150), pygame.SRCALPHA)

        # Draw a circle onto the temporary surface
        pygame.draw.circle(
            surface,
            (255, 200, 50, int(self.alpha)),  # RGBA color (last value is transparency)
            (75, 75),                         # Center of temporary surface
            int(self.radius)                  # Current explosion radius
        )

        # Blit (draw) the explosion surface onto the main screen
        # Offset by 75 to center the explosion at self.pos
        screen.blit(surface, (self.pos.x - 75, self.pos.y - 75))

    def finished(self):
        # Explosion ends when fully faded OR reaches max size
        return self.alpha <= 0 or self.radius >= self.max_radius


class Button:
    """
    Generic reusable button component.
    Handles:
    - Drawing itself
    - Hover effect
    - Detecting clicks
    """

    def __init__(self, rect, text, font, color, hover_color, text_color=colors["black"]):
        self.rect = pygame.Rect(rect)  # Button position and size stored as a Rect
        self.text = text               # Text displayed on button
        self.font = font               # Font object used to render text
        self.color = color             # Normal background color
        self.hover_color = hover_color # Background color when mouse hovers
        self.text_color = text_color   # Color of text

    def draw(self, screen):
        # Check if mouse is currently over button
        hovered = self.rect.collidepoint(pygame.mouse.get_pos())

        # Draw rectangle using hover color if mouse is over it
        pygame.draw.rect(screen, self.hover_color if hovered else self.color, self.rect)

        # Render the button text to a surface
        text_surface = self.font.render(self.text, True, self.text_color)

        # Center text within the button rectangle
        text_rect = text_surface.get_rect(center=self.rect.center)

        # Draw text onto the screen
        screen.blit(text_surface, text_rect)

    def is_clicked(self, event):
        # Return True if:
        # - Mouse button pressed
        # - Left mouse button (button 1)
        # - Click occurred inside button rectangle
        return (
            event.type == pygame.MOUSEBUTTONDOWN and
            event.button == 1 and
            self.rect.collidepoint(event.pos)
        )


class Scene:
    """
    Base scene class.
    All specific scenes (MenuScene, GameScene, etc.)
    inherit from this to enforce a consistent interface.
    """

    def __init__(self, game):
        self.game = game  # Reference to the main Game object (shared global state)

    def handle_event(self, event):
        # Placeholder method — child classes override this
        pass

    def update(self, dt):
        # Placeholder method — child classes override this
        pass

    def draw(self, screen):
        # Placeholder method — child classes override this
        pass

class MenuScene(Scene):
    def __init__(self, game):
        super().__init__(game)  # Call parent Scene constructor and store game reference

        # Get screen dimensions so UI can scale dynamically
        screen_width = self.game.screen.get_width()
        screen_height = self.game.screen.get_height()

        # Create fonts scaled relative to screen height
        # Using proportional scaling makes UI resolution-independent
        self.title_font = pygame.font.Font(None, int(screen_height * 0.12))
        self.font = pygame.font.Font(None, int(screen_height * 0.05))

        # Render title text surface once (no need to re-render every frame)
        self.title_text = self.title_font.render("Clicker Game", True, colors["white"])

        # Center title horizontally, position near top (1/6 down screen)
        self.title_rect = self.title_text.get_rect(
            center=(screen_width // 2, screen_height // 6)
        )

        # Padding inside each button (space between text and border)
        self.button_padding_x = 20
        self.button_padding_y = 10

        # Vertical spacing between buttons
        self.spacing = screen_height * 0.03

        # Text labels for each button
        button_texts = ["Play", "Shop", "Quit"]

        self.buttons = []  # List to store button objects

        # Starting vertical position for first button
        start_y = screen_height // 2

        # Create each button dynamically
        for i, text in enumerate(button_texts):

            # Compute vertical position for each button
            center_y = start_y + i * (self.font.get_height() + self.spacing)

            # Create button centered horizontally
            button = self.create_button(text, screen_width // 2, center_y)

            # Store button in list
            self.buttons.append(button)

    def create_button(self, text, center_x, center_y):

        # Render text to calculate its pixel size
        text_surface = self.font.render(text, True, colors["black"])
        text_width, text_height = text_surface.get_size()

        # Add horizontal and vertical padding to determine final button size
        button_width = text_width + self.button_padding_x * 2
        button_height = text_height + self.button_padding_y * 2

        # Create rectangle so button is centered at (center_x, center_y)
        rect = (
            int(center_x - button_width / 2),   # Left position
            int(center_y - button_height / 2),  # Top position
            int(button_width),                  # Width
            int(button_height)                  # Height
        )

        # Return a Button object with normal + hover colors
        return Button(rect, text, self.font, colors["gray"], colors["lightgray"])

    def handle_event(self, event):

        # Check each button for click events
        for button in self.buttons:
            if button.is_clicked(event):

                # Change scene based on which button was clicked
                if button.text == "Play":
                    self.game.change_scene(GameScene(self.game))  # Switch to gameplay

                elif button.text == "Shop":
                    self.game.change_scene(ShopScene(self.game))  # Switch to shop

                elif button.text == "Quit":
                    self.game.running = False  # Stop main game loop

    def draw(self, screen):

        screen.fill(colors["mainmenured"])  # Fill background

        # Draw title
        screen.blit(self.title_text, self.title_rect)

        # Draw all buttons
        for button in self.buttons:
            button.draw(screen)


class GameScene(Scene):
    def __init__(self, game):
        super().__init__(game)  # Initialize base Scene

        # Cache screen dimensions
        screen_width = self.game.screen.get_width()
        screen_height = self.game.screen.get_height()

        self.timer = 20  # Level duration in seconds

        # Font for timer and UI text
        self.timer_font = pygame.font.Font(None, int(screen_height * 0.05))
        self.font = pygame.font.Font(None, int(screen_height * 0.05))

        # Responsive sizing for back button
        button_width = screen_width * 0.08
        button_height = screen_height * 0.06
        button_margin = screen_width * 0.01

        # Create back button positioned in top-left corner
        self.back_button = Button(
            (button_margin, button_margin, button_width, button_height),
            "Back",
            self.font,
            colors["gray"],
            colors["lightgray"]
        )

        # Create list of moving target objects
        # Each target is represented as a dictionary (lightweight entity)
        self.targets = [
            {
                "rect": pygame.Rect(screen_width // 3, screen_height // 3, 200, 200),
                # Rectangle defines position and size

                "vel": pygame.Vector2(350, 280),
                # Velocity vector (pixels per second)

                "color": colors["red"],  # Current display color

                "original_color": colors["red"]
                # Used to reset color after being clicked
            },
            {
                "rect": pygame.Rect(screen_width // 2, screen_height // 2, 150, 150),
                "vel": pygame.Vector2(200, 400),
                "color": colors["blue"],
                "original_color": colors["blue"]
            },
        ]

        self.message = "Click the squares!"  # On-screen message
        self.message_timer = 0               # Controls how long message displays
        self.click_count = 0                 # Tracks successful hits
        self.explosions = []                 # Active explosion effects

    def handle_event(self, event):
        # Delegate click detection to the back button component.
        # If activated, transition control flow back to the MenuScene via the Game controller.
        if self.back_button.is_clicked(event):
            self.game.change_scene(MenuScene(self.game))

        # Iterate over all interactive target entities in the scene.
        for target in self.targets:

            # Validate a legitimate "hit" interaction by ensuring:
            # - The event is a mouse button press
            # - The left mouse button (button 1) was used
            # - The click occurred within the target's rectangular bounds
            # - The target has not already been marked as hit (green state prevents double scoring)
            if (
                    event.type == pygame.MOUSEBUTTONDOWN
                    and event.button == 1
                    and target["rect"].collidepoint(event.pos)
                    and target["color"] != colors["green"]
            ):
                # Change visual state to indicate successful hit.
                target["color"] = colors["green"]

                # Provide immediate UI feedback to reinforce player interaction.
                self.message = "Nice hit!"
                self.message_timer = 0.75  # Display message for 0.75 seconds.

                # Increment performance tracking metric.
                self.click_count += 1

                # Award in-game currency for successful interaction.
                self.game.coins += 2

                # If explosion feature is unlocked, spawn visual + audio feedback.
                if self.game.explosion_bought:
                    self.explosions.append(Explosion(event.pos))  # Instantiate explosion at click location.
                    self.game.explosion_sound.play()  # Play associated sound effect.

    def update(self, dt):
        # Query current screen dimensions dynamically (supports window resizing).
        screen_width = self.game.screen.get_width()
        screen_height = self.game.screen.get_height()

        # Decrement level timer using delta time (frame-rate independent countdown).
        self.timer -= dt

        # When timer expires, transition to level completion scene.
        if self.timer <= 0:
            self.game.change_scene(LevelCompletionScene(self.game))

        # Update target positions using velocity-based motion (Euler integration).
        for target in self.targets:

            # Integrate velocity into position:
            # new_position = current_position + velocity * delta_time
            target["rect"].x += target["vel"].x * dt
            target["rect"].y += target["vel"].y * dt

            # Horizontal boundary collision detection.
            # If the target exceeds left or right bounds, reverse horizontal velocity.
            if target["rect"].left < 0 or target["rect"].right > screen_width:
                target["vel"].x *= -1  # Reflect velocity (elastic bounce).

            # Vertical boundary collision detection.
            # If the target exceeds top or bottom bounds, reverse vertical velocity.
            if target["rect"].top < 0 or target["rect"].bottom > screen_height:
                target["vel"].y *= -1  # Reflect velocity (elastic bounce).

        # Manage temporary UI message lifecycle.
        if self.message_timer > 0:
            self.message_timer -= dt  # Decrease message timer.

            # When timer expires, clear message and restore target colors.
            if self.message_timer <= 0:
                self.message = ""  # Remove message from screen.

                # Reset any targets that were marked green back to their original color.
                for target in self.targets:
                    if target["color"] == colors["green"]:
                        target["color"] = target["original_color"]

        # Update explosion animation objects.
        # Iterate over a shallow copy to allow safe removal during iteration.
        for explosion in self.explosions[:]:
            explosion.update(dt)  # Advance animation state.

            # Remove explosion once its lifecycle is complete.
            if explosion.finished():
                self.explosions.remove(explosion)

    def draw(self, screen):
        # Clear previous frame by filling entire screen with black.
        screen.fill(colors["black"])

        # Draw UI back button.
        self.back_button.draw(screen)

        # Render remaining time (integer conversion avoids flickering decimals).
        timer_surface = self.timer_font.render(
            f"Time: {int(self.timer)}",
            True,
            colors["white"]
        )

        # Position timer near top-right corner using proportional placement.
        screen.blit(
            timer_surface,
            (screen.get_width() * 0.85, screen.get_height() * 0.02)
        )

        # Render each target rectangle with its current color state.
        for target in self.targets:
            pygame.draw.rect(screen, target["color"], target["rect"])

        # Render all active explosion animations.
        for explosion in self.explosions:
            explosion.draw(screen)

        # Render temporary feedback message if it exists.
        if self.message:
            text_surface = self.font.render(self.message, True, colors["white"])

            # Center horizontally and position at 75% vertical screen height.
            text_rect = text_surface.get_rect(
                center=(screen.get_width() // 2, int(screen.get_height() * 0.75))
            )

            screen.blit(text_surface, text_rect)

        # Render performance metrics (hit count).
        screen.blit(
            self.font.render(f"Hits: {self.click_count}", True, colors["white"]),
            (screen.get_width() * 0.01, screen.get_height() * 0.08)
        )

        # Render in-game currency counter in yellow for visual emphasis.
        screen.blit(
            self.font.render(f"Coins: {self.game.coins}", True, colors["yellow"]),
            (screen.get_width() * 0.01, screen.get_height() * 0.15)
        )

class ShopScene(Scene):
    def __init__(self, game):
        # Initialize base Scene class and retain reference to Game controller.
        # The Game object acts as the central state manager across scenes.
        super().__init__(game)

        # Retrieve dynamic screen dimensions.
        # This enables resolution-independent layout scaling.
        screen_width = self.game.screen.get_width()
        screen_height = self.game.screen.get_height()

        # Create fonts scaled proportionally to screen height.
        # This maintains UI consistency across different resolutions.
        self.title_font = pygame.font.Font(None, int(screen_height * 0.12))
        self.font = pygame.font.Font(None, int(screen_height * 0.05))

        # Render static "Shop" title text surface.
        self.title_text = self.title_font.render("Shop", True, colors["white"])

        # Center title horizontally and position it near the top of the screen.
        self.title_rect = self.title_text.get_rect(
            center=(screen_width // 2, screen_height // 11)
        )

        # Define internal padding for buttons.
        # Padding ensures text is visually separated from button borders.
        self.button_padding_x = 20
        self.button_padding_y = 10

        # Create a back button positioned near the top-left corner.
        # Uses proportional placement for responsive layout.
        self.back_button = self.create_button(
            "Back",
            screen_width * 0.05,
            screen_height * 0.05
        )

        # Dynamically determine explosion button label based on purchase state.
        # This ensures UI accurately reflects game state.
        text = (
            "Explosions (Bought)"
            if self.game.explosion_bought
            else "Explosions on hit (20 coins)"
        )

        # Create explosion purchase button centered on the screen.
        self.explosion_button = self.create_button(
            text,
            screen_width // 2,
            screen_height // 2
        )

        # Store buttons in iterable collection for rendering and scalability.
        self.buttons = [self.back_button, self.explosion_button]


    def create_button(self, text, center_x, center_y):
        # Render the text to a temporary surface to measure its pixel dimensions.
        # This allows precise calculation of button size.
        text_surface = self.font.render(text, True, colors["black"])

        # Extract width and height of rendered text.
        w, h = text_surface.get_size()

        # Compute button rectangle centered at (center_x, center_y),
        # adding padding around the text to form the clickable region.
        rect = (
            int(center_x - (w + self.button_padding_x * 2) / 2),
            int(center_y - (h + self.button_padding_y * 2) / 2),
            int(w + self.button_padding_x * 2),
            int(h + self.button_padding_y * 2)
        )

        # Return fully constructed Button object with normal and hover colors.
        return Button(rect, text, self.font, colors["gray"], colors["lightgray"])


    def handle_event(self, event):
        # If the back button is clicked, transition back to the main menu.
        if self.back_button.is_clicked(event):
            self.game.change_scene(MenuScene(self.game))

        # Process explosion purchase only if:
        # - It has not already been purchased
        # - The explosion button was clicked
        if not self.game.explosion_bought and self.explosion_button.is_clicked(event):

            # Ensure player has sufficient in-game currency before allowing purchase.
            if self.game.coins >= 20:
                self.game.coins -= 20  # Deduct purchase cost from player balance.
                self.game.explosion_bought = True  # Unlock explosion feature globally.

                # Update button label to reflect purchased state.
                # This prevents repeat purchases and communicates state change to user.
                self.explosion_button.text = "Explosions (Bought)"


    def draw(self, screen):
        # Clear the frame using shop-specific background color.
        screen.fill(colors["shoppurple"])

        # Render shop title.
        screen.blit(self.title_text, self.title_rect)

        # Draw all buttons in the scene.
        for button in self.buttons:
            button.draw(screen)

        # Display player's current coin balance in yellow for visual prominence.
        screen.blit(
            self.font.render(f"Coins: {self.game.coins}", True, colors["yellow"]),
            (screen.get_width() * 0.01, screen.get_height() * 0.15)
        )

class LevelCompletionScene(Scene):
    def __init__(self, game):
        # Initialize base Scene class and retain shared Game state reference.
        # This allows access to global resources such as screen, coins, etc.
        super().__init__(game)

        # Retrieve current display resolution dynamically.
        # This supports resolution-independent UI scaling.
        screen_width = self.game.screen.get_width()
        screen_height = self.game.screen.get_height()

        # Create scalable fonts proportional to screen height.
        # Using screen-relative sizing ensures consistent UI proportions.
        self.title_font = pygame.font.Font(None, int(screen_height * 0.12))
        self.font = pygame.font.Font(None, int(screen_height * 0.05))

        # Render static completion message text surface.
        # Pre-rendering avoids recalculating every frame.
        self.title_text = self.title_font.render("Level Completed!", True, colors["white"])

        # Center title horizontally and position near the top.
        # get_rect() provides a Rect aligned to the rendered surface.
        self.title_rect = self.title_text.get_rect(
            center=(screen_width // 2, screen_height // 11)
        )

        # Compute back button dimensions proportionally to screen size.
        button_width = screen_width * 0.08
        button_height = screen_height * 0.06
        button_margin = screen_width * 0.01  # Margin from screen edge

        # Instantiate reusable Button object for navigation back to menu.
        self.back_button = Button(
            (button_margin, button_margin, button_width, button_height),
            "Back",
            self.font,
            colors["gray"],
            colors["lightgray"]
        )

    def handle_event(self, event):
        # Delegate click detection to Button abstraction.
        # If back button is pressed, transition to main menu scene.
        if self.back_button.is_clicked(event):
            self.game.change_scene(MenuScene(self.game))

    def draw(self, screen):
        # Clear frame buffer using red background to signify completion state.
        screen.fill(colors["red"])

        # Draw pre-rendered completion title.
        screen.blit(self.title_text, self.title_rect)

        # Render back button on top of background.
        self.back_button.draw(screen)

class Game:
    def __init__(self, width=1920, height=1080):
        # Initialize all imported pygame modules.
        pygame.init()

        # Initialize audio mixer subsystem separately.
        pygame.mixer.init()

        # Increase available concurrent audio channels.
        # Prevents sound clipping if multiple sounds overlap.
        pygame.mixer.set_num_channels(16)

        # Create primary display surface with specified resolution.
        # This is the framebuffer for all rendering operations.
        self.screen = pygame.display.set_mode((width, height))

        # Set OS-level window title.
        pygame.display.set_caption("Click Game")

        # Create Clock object for frame rate regulation.
        # Used to compute delta time (dt).
        self.clock = pygame.time.Clock()

        # Global execution flag controlling main loop lifecycle.
        self.running = True

        # Persistent game state variables.
        self.coins = 0                # Player currency
        self.explosion_bought = False # Shop unlock flag

        # Load explosion sound effect from disk into memory.
        # This is done once to avoid runtime disk I/O latency.
        self.explosion_sound = pygame.mixer.Sound("assets/explosion.wav")

        # Reduce playback volume to 40% to prevent clipping.
        self.explosion_sound.set_volume(0.4)

        # Initialize first active scene (Main Menu).
        # Scene architecture enables modular state transitions.
        self.current_scene = MenuScene(self)

    def change_scene(self, scene):
        # Centralized scene switching mechanism.
        # Ensures only one scene is active at any time.
        self.current_scene = scene

    def run(self):
        # Main game loop (real-time simulation loop).
        while self.running:

            # Limit execution to 60 frames per second.
            # Returns milliseconds since last tick.
            dt = self.clock.tick(60) / 1000  # Convert ms → seconds

            # Event polling phase.
            # Processes all queued input/system events.
            for event in pygame.event.get():

                # Handle OS window close event.
                if event.type == pygame.QUIT:
                    self.running = False

                # Delegate input handling to active scene.
                self.current_scene.handle_event(event)

            # Update simulation state of active scene.
            # dt ensures frame-rate independent motion/logic.
            self.current_scene.update(dt)

            # Render active scene to screen buffer.
            self.current_scene.draw(self.screen)

            # Swap display buffers (double buffering).
            # Makes rendered frame visible.
            pygame.display.flip()

        # Clean shutdown of pygame subsystems.
        pygame.quit()


# Standard Python entry-point guard.
# Ensures game runs only when file is executed directly,
# not when imported as a module.
if __name__ == "__main__":
    Game().run()
