/* import unittest
import pygame
from main import Platform, Projectile, Spike, GameScene

pygame.init()


# 2 black-box tests
class TestProjectileBlackBox(unittest.TestCase):

    def test_projectile_moves_right(self):
        p = Projectile(100, 100, 1)
        p.update(1)

        self.assertGreater(p.rect.x, 100)
        self.assertEqual(p.rect.y, 100)

    def test_projectile_moves_left(self):
        p = Projectile(100, 100, -1)
        p.update(1)

        self.assertLess(p.rect.x, 100)
        self.assertEqual(p.rect.y, 100)



#  4 white-box tests
class TestMoveAndCollideWhiteBox(unittest.TestCase):

    # branch coverage of move_and_collide()
    def setUp(self):
        class FakeGame:
            screen = pygame.display.set_mode((800, 600))

        self.scene = GameScene(FakeGame())

        self.platform = Platform((200, 200, 200, 20))
        self.scene.platforms = [self.platform]

    def test_horizontal_collision(self):
        player = pygame.Rect(150, 200, 50, 50)
        velocity = pygame.Vector2(200, 0)

        self.scene.move_and_collide(player, velocity, 1)

        self.assertEqual(player.right, self.platform.rect.left)

        self.assertEqual(player.top, 200)

    def test_horizontal_collision_from_right(self):
        player = pygame.Rect(450, 200, 50, 50)
        velocity = pygame.Vector2(-200, 0)

        self.scene.move_and_collide(player, velocity, 1)

        self.assertEqual(player.left, self.platform.rect.right)
        self.assertEqual(player.top, 200)

    def test_vertical_landing(self):
        player = pygame.Rect(220, 150, 50, 50)
        velocity = pygame.Vector2(0, 60)

        grounded = self.scene.move_and_collide(player, velocity, 1)

        self.assertTrue(grounded)
        self.assertEqual(player.bottom, self.platform.rect.top)

    def test_vertical_collision_from_below(self):
        player = pygame.Rect(220, 220, 50, 50)
        velocity = pygame.Vector2(0, -60)

        self.scene.move_and_collide(player, velocity, 1)

        self.assertEqual(player.top, self.platform.rect.bottom)


# 1 Integration test
class TestProjectilePlayerIntegration(unittest.TestCase):

    # Projectile and GameScene
    def test_projectile_hits_player_resets_player(self):

        class FakeGame:
            def __init__(self):
                self.screen = pygame.display.set_mode((800, 600))

            def change_scene(self, scene):
                pass

        scene = GameScene(FakeGame())

        scene.player.topleft = (400, 400)

        projectile = Projectile(scene.player.x, scene.player.y, 1)
        scene.projectiles.append(projectile)

        scene.update(0.01)

        self.assertEqual(scene.player.topleft, (100, scene.game.screen.get_height() - 150))

        self.assertNotIn(projectile, scene.projectiles)


if __name__ == "__main__":
    unittest.main()