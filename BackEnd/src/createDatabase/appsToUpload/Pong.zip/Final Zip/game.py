import pygame

from paddle import Paddle
from ball import Ball

class Game:
    def __init__(self):
        pygame.init()

        self.width = 1280 
        self.height = 720 
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.RESIZABLE)
        pygame.display.set_caption("Pong")

        self.running = True  # used to close out of the game 
        self.clock = pygame.time.Clock() 

        self.ball = Ball(self.width, self.height)

        # self.player = Paddle(30, self.height, "assets/newplayerPaddle.png")

        # self.opponent = Paddle(self.width - 128 - 30, self.height, "assets/newopponentPaddle.png") # did have help with ai for determining how the spacing for the paddles should be, 

        self.player = Paddle(30, self.height)
        self.opponent = Paddle(self.width - 50, self.height)

        self.playerScore = 0
        self.opponentScore = 0

        self.playerScore = 0
        self.opponentScore = 0

        print("Players moves with W and S")
        print("Opponent moves with arrow up and arrow down")

        self.font = pygame.font.Font(None, 50)  # default pygame font

        self.opponentHits = 0
        self.buffActive = False
        self.buffEndTime = 0
        self.buffMultiplier = 2.5
        self.originalVelocity = None
        self.buffHits = 0

    def buffs(self):

        # Activate buff after 2 hits
        if self.opponentHits >= 2 and not self.buffActive:
            self.ball.velocity *= self.buffMultiplier
            self.buffActive = True
            self.buffHits = 0
            self.opponentHits = 0

        # While buff active count hits
        elif self.buffActive:
            self.buffHits += 1

            if self.buffHits >= 2:
                self.ball.velocity /= self.buffMultiplier
                self.buffActive = False
                self.buffHits = 0

    def updateScore(self, collision):
        if collision == "player":
            self.playerScore += 1
        elif collision == "opponent":
            self.opponentScore += 1

       

    def movePlayerUp(self):
        self.player.rect.y -= 9

    def movePlayerDown(self):
        self.player.rect.y += 9

    def moveOpponentUp(self):
        self.opponent.rect.y -= 9

    def moveOpponentDown(self):
        self.opponent.rect.y += 9

    def gameReset(self): 
        self.ball.rect.center = (self.width // 2, self.height // 2)
        self.ball.velocity = pygame.Vector2(self.ball.speed, 0)

        self.player.rect.centery = self.height // 2
        self.opponent.rect.centery = self.height // 2
    

    def drawScore(self):
        scoreText = self.font.render(
            f"{self.playerScore}  {self.opponentScore}", True, (255,255,255)
        )

        self.screen.blit(scoreText, (self.width//2 - 50, 20))


    def run(self):
        while self.running:
            self.clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            keys = pygame.key.get_pressed()
            paddle_speed = 9

            # for game reset
            if keys[pygame.K_BACKSPACE]: 
                self.gameReset()

            if keys[pygame.K_w]:
                self.movePlayerUp()

            if keys[pygame.K_s]:
                self.movePlayerDown()
            

            # Opponent tracking 
            ai_speed = 4   # ball speed is 6

            # only track when ball moving toward opponent
            if self.ball.velocity.x > 0:

                if self.ball.rect.centery < self.opponent.rect.centery - 10:
                    self.opponent.rect.y -= ai_speed

                elif self.ball.rect.centery > self.opponent.rect.centery + 10:
                    self.opponent.rect.y += ai_speed

            # keep playerPaddle on screen
            if self.player.rect.top < 0:
                self.player.rect.top = 0

                
            if self.player.rect.bottom > self.height:
                self.player.rect.bottom = self.height


            # keep opponentPaddle on screen
            if self.opponent.rect.top < 0:
                self.opponent.rect.top = 0

            if self.opponent.rect.bottom > self.height:
                self.opponent.rect.bottom = self.height


            self.screen.fill((0, 0, 0))
            
            self.ball.update()

           # offset = (
           #     self.ball.rect.left - self.player.rect.left,
           #    self.ball.rect.top - self.player.rect.top
            #)

           # ball_mask = self.ball.mask

            # if self.player.mask.overlap(ball_mask, offset) and self.ball.velocity.x < 0:
            if self.player.rect.colliderect(self.ball.rect) and self.ball.velocity.x < 0:
                self.ball.rect.x = self.ball.prev_x
                self.ball.rect.y = self.ball.prev_y

                hit_pos = self.ball.rect.centery - self.player.rect.top
                zone_size = self.player.rect.height / 3

                if hit_pos < zone_size:
                    self.ball.velocity = pygame.Vector2(9, -3)
                elif hit_pos < zone_size * 2:
                    self.ball.velocity = pygame.Vector2(9, 0)
                else:
                    self.ball.velocity = pygame.Vector2(9, 3)

            # opponent collision
          #  offset = (
           #     self.ball.rect.left - self.opponent.rect.left,
          #      self.ball.rect.top - self.opponent.rect.top
          #  )

            # if self.opponent.mask.overlap(ball_mask, offset) and self.ball.velocity.x > 0:
            if self.opponent.rect.colliderect(self.ball.rect) and self.ball.velocity.x > 0:
                self.ball.rect.x = self.ball.prev_x
                self.ball.rect.y = self.ball.prev_y

                hit_pos = self.ball.rect.centery - self.opponent.rect.top
                zone_size = self.opponent.rect.height / 3

                if hit_pos < zone_size:
                    self.ball.velocity = pygame.Vector2(-9, -3)
                elif hit_pos < zone_size * 2:
                    self.ball.velocity = pygame.Vector2(-9, 0)
                else:
                    self.ball.velocity = pygame.Vector2(-9, 3)

                self.opponentHits += 1
                self.buffs()

            collision = self.ball.checkCollisions(self.width, self.height)

            if collision is not None:
                self.updateScore(collision)

            
                if collision == "player":
                    print("Player scored!")
                else:
                    print("Opponent scored!")

                print("Score:", self.playerScore, "-", self.opponentScore)
                self.gameReset()

          

            self.ball.draw(self.screen)
            self.player.draw(self.screen)
            self.opponent.draw(self.screen)

            
            self.drawScore()

            pygame.display.flip()

        pygame.quit()